import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FunTrigonometrica extends Frame implements ActionListener {
	JLabel lblFuncion;
	JTextField txtPrecio;
	JButton btnAceptar,btnSalir;
	JPanel pnDatos,pnBotones, pnResultado;
	JTextArea resultado;
	JScrollPane barras;
	JRadioButton rbSeno,rbCoseno;
	
	private static final String ACEPTAR="Aceptar";
	private static final String SALIR="Salir";

	double valorPagar;

	public FunTrigonometrica() {
		lblFuncion=new JLabel("Funcion");
		txtPrecio =new JTextField();
		
		rbSeno=new JRadioButton("Seno",true);
		rbCoseno=new JRadioButton("Coseno");

		//CREACION DE UN GRUPO DE RADIO BUTTON...JButronGroup
		ButtonGroup bgrupoFuncion=new ButtonGroup();
		bgrupoFuncion.add(rbSeno);
		bgrupoFuncion.add(rbCoseno);
		
		resultado=new JTextArea();
		barras=new JScrollPane(resultado);
		barras.setBounds(5,5, 30,30);
		 
		
		btnAceptar=new JButton("Aceptar");
		btnAceptar.setPreferredSize(new Dimension(200,25));
		btnAceptar.setActionCommand(ACEPTAR);
		btnAceptar.addActionListener(this);
		
		btnSalir=new JButton("Salir");
		btnSalir.setPreferredSize(new Dimension(200,25));
		btnSalir.setActionCommand(SALIR);
		btnSalir.addActionListener(this);
		
		pnDatos=new JPanel();
		pnResultado=new JPanel();
		pnBotones =new JPanel();
		
		
		pnDatos.setLayout(new GridLayout(1,3));
		pnDatos.add(lblFuncion);
		pnDatos.add(rbSeno);
		pnDatos.add(rbCoseno);
		
		pnResultado.setLayout(new GridLayout(1,1));
		pnResultado.add(barras);
		
		
		pnBotones.setLayout(new GridLayout(1,2));
		pnBotones.add(btnAceptar);
		pnBotones.add(btnSalir);
		
		setTitle("Ejercicio 2: Funciones Trigonometricas");
		this.setSize(270,350);
		this.add(pnDatos,"North");
		this.add(pnResultado,"Center");
		this.add(pnBotones,"South");
		setResizable(true);
		setLocationRelativeTo(null);
	}
		
    public void actionPerformed(ActionEvent e) {
		String evento=e.getActionCommand();
		if(evento.equals(ACEPTAR)) {
			
			if(rbSeno.isSelected()){
				resultado.setText("");
				resultado.append("Angulo  "+"             Seno    "+"\n");
				for(int i=0;i<=360; i++) {
				       double Radianseno=Math.toRadians(i);
				       double seno=Math.sin(Radianseno);
				       resultado.append(i+"                    "+seno+"\n");
				}
				double x=2.54;
	
			 }
	
			if(rbCoseno.isSelected()){
				resultado.setText("");
				resultado.append("Angulo  "+"              Coseno    "+"\n");
				for(int i=0;i<=360; i++) {
				       double Radiancoseno=Math.toRadians(i);
				       double coseno=Math.cos(Radiancoseno);
				       resultado.append(i+"                     "+coseno+"\n");
				   }
			 }
		}
	    if(evento.equals(SALIR)) {
		  System.exit(0);
		}
    }
    public static void main(String[] args) {
	    	FunTrigonometrica formulario=new FunTrigonometrica();
			formulario.setVisible(true);
	}

}


