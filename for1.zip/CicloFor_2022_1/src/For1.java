import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class For1 extends Frame implements ActionListener {
JLabel lblPrecio;
JTextField txtPrecio;
JButton btnAceptar,btnSalir;
JPanel pnDatos,pnBotones, pnResultado;
JTextArea resultado;
JScrollPane barras;
private static final String ACEPTAR="Aceptar";
private static final String SALIR="Salir";

double valorPagar;

public For1() {
	lblPrecio=new JLabel("Precio");
	txtPrecio =new JTextField();
	
	resultado=new JTextArea();
	barras=new JScrollPane(resultado);
	barras.setBounds(5,5, 30,30);
	 
	btnAceptar=new JButton("Aceptar");
	btnAceptar.setPreferredSize(new Dimension(200,25));
	btnAceptar.setActionCommand(ACEPTAR);
	btnAceptar.addActionListener(this);
	
	btnSalir=new JButton("Salir");
	btnSalir.setPreferredSize(new Dimension(200,25));
	btnSalir.setActionCommand(SALIR);
	btnSalir.addActionListener(this);
	
	pnDatos=new JPanel();
	pnResultado=new JPanel();
	pnBotones =new JPanel();
	
	
	pnDatos.setLayout(new GridLayout(1,2));
	pnDatos.add(lblPrecio);
	pnDatos.add(txtPrecio);
	
	pnResultado.setLayout(new GridLayout(1,1));
	pnResultado.add(barras);
	
	
	pnBotones.setLayout(new GridLayout(1,2));
	pnBotones.add(btnAceptar);
	pnBotones.add(btnSalir);
	
	setTitle("Ejercicio 1 Ciclo For");
	this.setSize(200,200);
	this.add(pnDatos,"North");
	this.add(pnResultado,"Center");
	this.add(pnBotones,"South");
	setResizable(true);
	setLocationRelativeTo(null);
}
	
	public void actionPerformed(ActionEvent e) {
		String evento=e.getActionCommand();
		int precio= Integer.parseInt(txtPrecio.getText()); 
		if(evento.equals(ACEPTAR)) {
			    resultado.append("Cant    "+"V.U     "+"Valor a Pagar"+"\n");
			for(int i=1;i<=20; i++) {
				valorPagar=i*precio;
				resultado.append(i+"   *      "+precio+"   =  "+valorPagar+"\n");
			}
			
			
		}
       if(evento.equals(SALIR)) {
			System.exit(0);
		}
		
	}
	public static void main(String[] args) {
		For1 formulario=new For1();
		formulario.setVisible(true);
	}

}
