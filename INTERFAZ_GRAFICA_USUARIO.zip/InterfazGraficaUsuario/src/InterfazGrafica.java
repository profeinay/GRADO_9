import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class InterfazGrafica extends Frame implements ActionListener {
JLabel lblNombre,lblDireccion,lblCiudad,lblEstadoCivil, lblSexo, lblHobbye;
JTextField txtNombre,txtDireccion;
JButton btnAceptar, btnCancelar, btnSalir, btnConsultar;
JComboBox cboCiudad,cboEstadoCivil;
JRadioButton rbMasculino,rbFemenino;
JTextArea jtaResultado;
JCheckBox cbMusica,cbDanza, cbFutbol, cbPasear,cbLectura;
JScrollPane scBarras;
JList jlCiudad;
JPanel pnBotones, pnDatos, pnResultado,pnImagen,pnSexo, pnHobbye,pnFinal, pnAuxiliar,pnDefinitivo;

int sentinela=0;

private static final String ACEPTAR="Aceptar";
private static final String CANCELAR="Cancelar";
private static final String SALIR ="Salir";
private static final String CONSULTAR ="Consultar";

// CONSTRUCTOR DE LA CLASE
public InterfazGrafica(){
	
// CREACION DE LOS JLABEL...JLabel
lblNombre=new JLabel("Nombre del Empleado");    	
lblDireccion=new JLabel("Direccion");
lblCiudad=new JLabel("Ciudad");
lblEstadoCivil=new JLabel("Estado Civil");
lblSexo=new JLabel("Sexo");
lblHobbye=new JLabel("Hobbye");

// CREACION DE LOS JTEXTFIELD...JTextfield
txtNombre= new JTextField();
txtDireccion=new JTextField();

//CREACION DE JCOMBOBOX...JComboBox
cboCiudad=new JComboBox();
cboCiudad.addItem("Seleccione una Ciudad");
cboCiudad.addItem("Espinal");
cboCiudad.addItem("Ibague");
cboCiudad.addItem("Guamo");
cboCiudad.addItem("Salda�a");
cboCiudad.addItem("Flandes");
cboCiudad.addItem("Purificaci�n");
cboCiudad.addItem("Suarez");
cboCiudad.addItem("Alvarado");
cboCiudad.addItem("Mariquita");
cboCiudad.addItem("Libano");
cboCiudad.addItem("Honda");

cboEstadoCivil=new JComboBox();
cboEstadoCivil.addItem("Seleccione un Estado Civil");
cboEstadoCivil.addItem("Casado");
cboEstadoCivil.addItem("Divorsiado");
cboEstadoCivil.addItem("Union Libre");
cboEstadoCivil.addItem("Viudo");
cboEstadoCivil.addItem("Soltero(a)");

//CREACION DE JLIST...JList
jlCiudad=new JList();
DefaultListModel ciudad = new DefaultListModel();
ciudad.addElement("Seleccione una Ciudad");
ciudad.addElement("Espinal");
ciudad.addElement("Ibague");
ciudad.addElement("Guamo");
ciudad.addElement("Saldaña");
ciudad.addElement("Castilla");
jlCiudad.setModel(ciudad);

//CREACION DE LOS RADIOBUTTON..JRadioButton
rbMasculino=new JRadioButton("Masculino",true);
rbFemenino=new JRadioButton("Femenino");

//CREACION DE UN GRUPO DE RADIO BUTTON...JButronGroup
ButtonGroup bgrupoSexo=new ButtonGroup();
bgrupoSexo.add(rbMasculino);
bgrupoSexo.add(rbFemenino);

// CREACION DE  JCHECKBOX...JCheckBox
cbMusica=new JCheckBox("Música");
cbDanza=new JCheckBox("Danza");
cbFutbol=new JCheckBox("Futbol");
cbPasear=new JCheckBox("Pasear");
cbLectura=new JCheckBox("Lectura");

//CREACION DE JTEXTAREA....JTextArea
//CREACION DE JSCROLLPANE O BARRAS DE DESPLAZAMIENTO;
jtaResultado=new JTextArea();
scBarras=new JScrollPane(jtaResultado);
scBarras.setBounds(5,5,20,20);

//CREACION DE LOS BOTONES DE COMANDO..JButton
btnAceptar=new JButton("Aceptar");
btnAceptar.setPreferredSize(new Dimension(200,25));
btnAceptar.setActionCommand(ACEPTAR);
btnAceptar.addActionListener(this);

btnCancelar=new JButton("Cancelar");
btnCancelar.setPreferredSize(new Dimension(200,25));
btnCancelar.setActionCommand(CANCELAR);
btnCancelar.addActionListener(this);

btnConsultar=new JButton("Consultar");
btnConsultar.setPreferredSize(new Dimension(200,25));
btnConsultar.setActionCommand(CONSULTAR);
btnConsultar.addActionListener(this);

btnSalir=new JButton("Salir");
btnSalir.setPreferredSize(new Dimension(200,25));
btnSalir.setActionCommand(SALIR);
btnSalir.addActionListener(this);

// PROCESO PARA INSERTAR IMAGENES 
// COPIE LA IMAGEN DENTRO DE LA CARPETA SRC DEL PROYECTO
// TENGA EN CUENTA LA EXTENSION DE LA IMAGEN (GIF, JTG, JPEG, PNG U OTROS)
// NO UTILIZAR NOMBRES LARGOS PARA LA IMAGEN
// NO UTILICE ESPACIOS EN LOS NOMBRES DE LA IMAGENES

 JLabel lblImagen=new JLabel(); // SE CREA UN JLABER
 lblImagen.setBounds(41,36,340,200); 
 ImageIcon icono=new ImageIcon(getClass().getResource("CARTAGENA.jpg")); //SE CREA UN OBJETO IMAGEICON
 // CREACION DE UN NUEVO OBJETO IMAGEICON QUE PERMITE CONFIGURAR EL TAMAÑO DE LA IMAGEN 
 ImageIcon img=new ImageIcon(icono.getImage().getScaledInstance(lblImagen.getWidth(),lblImagen.getHeight(),Image.SCALE_SMOOTH ));
 lblImagen.setIcon(img); // UBICACION DE LA IMAGEN EN UN LBLIMAGEN

//CREACION DE LOS JPANEL ....JPanel
 pnBotones =new JPanel();
 pnDatos =new JPanel();
 pnSexo =new JPanel();
 pnHobbye =new JPanel();
 pnResultado =new JPanel();
 pnImagen =new JPanel();
 pnFinal =new JPanel();
 pnAuxiliar=new JPanel();
 pnDefinitivo=new JPanel();

 //ORGANIZACION DE LOS ELEMENTOS DE LA INTERFAZ DENTRO DE LOS PANELES
 pnBotones.setLayout(new GridLayout(4,1));
 pnBotones.add(btnAceptar);
 pnBotones.add(btnCancelar);
 pnBotones.add(btnConsultar);
 pnBotones.add(btnSalir);
 
 pnDatos.setLayout(new GridLayout(4,2));
 pnDatos.add(lblNombre);
 pnDatos.add(txtNombre);
 pnDatos.add(lblDireccion);
 pnDatos.add(txtDireccion);
 pnDatos.add(lblCiudad);
 pnDatos.add(cboCiudad);
 pnDatos.add(lblEstadoCivil);
 pnDatos.add(cboEstadoCivil);
 
 pnSexo.setLayout(new GridLayout(1,3));
 pnSexo.add(lblSexo);
 pnSexo.add(rbMasculino);
 pnSexo.add(rbFemenino);
 
 pnHobbye.setLayout(new GridLayout(2,3));
 pnHobbye.add(lblHobbye);
 pnHobbye.add(cbMusica);
 pnHobbye.add(cbDanza);
 pnHobbye.add(cbFutbol);
 pnHobbye.add(cbPasear);
 pnHobbye.add(cbLectura);
 
 pnResultado.setLayout(new GridLayout(1,1));
 pnResultado.add(scBarras);

 pnImagen.setLayout(new GridLayout(1,1));
 pnImagen.add(lblImagen);
 
 pnFinal.setLayout(new GridLayout(4,1));
 pnFinal.add(pnDatos);
 pnFinal.add(pnSexo);
 pnFinal.add(pnHobbye);
 pnFinal.add(pnResultado);
 
 pnAuxiliar.setLayout(new GridLayout(2,1));
 pnAuxiliar.add(lblImagen);
 pnAuxiliar.add(pnBotones);
 
 pnDefinitivo.setLayout(new GridLayout(1,2));
 pnDefinitivo.add(pnFinal);
 pnDefinitivo.add(pnAuxiliar);
 
 // CONFIGRUACION DEL FORMULARIO Y UBICACION DE LOS PANELES DENTRO DEL FORMULARIO
 setTitle("Registro de Usuarios");
 this.setSize(700,440);
 this.add(pnDefinitivo,"North");
 setResizable(false);
 setLocationRelativeTo(null);
}

public void actionPerformed(ActionEvent ae){
	String evento=ae.getActionCommand();
	//DESCARGAR LOS VALORES DIGITADOS EN CADA UNO DE LOS CUADROS DE TEXTO DEL FORMULARIO A VARIABLES
	String nombre=txtNombre.getText(); //  DESCARGAR EL VALOR DIGITADO EN EL CAMPO TXTNOMBRE A LA VARIABLE NOMBRE
	String direccion=txtDireccion.getText();// DESCARGAR EL VALOR DIGITADO EN EL CAMPO TXTDIRECCION A LA VARIABLE DIRECCION
	String estadoCivil=(String)cboEstadoCivil.getSelectedItem(); //DESCARGAR EL ITEM SELECCIONADO EN EL COMBO CBOESTADOCIVIL EN LA VARIABLE ESTADOCIVIL
	String ciudad=(String)cboCiudad.getSelectedItem();//DESCARGAR EL ITEM SELECCIONADO EN EL COMBO CBOCIUDAD EN LA VARIABLE CIUDAD
	String sexo;
	// VALIDANDO LOS RADIO BUTON Y ASIGNANDO EL SEXO A LA VARIABLE SEXO
	 if(rbMasculino.isSelected()){
		 sexo="Masculino";
	 }else{
		 sexo="Femenino";
	 }
	 
	// VALIDANDO LA ACCION SELECCIONADA--> VALIDANDO CUAL BOTON RECIBIO UNA ORDEN 
	if(evento.equals(ACEPTAR)){
		if(ciudad.equals("Espinal")){
			JOptionPane.showMessageDialog(null, "Ha ingresado un Pelachivas...");
		}
		if(nombre.equals("")){
			 JOptionPane.showMessageDialog(null, "Falt� digitar el nombre", "ERROR....",JOptionPane.ERROR_MESSAGE);
		}
		if(direccion.equals("")){
			 JOptionPane.showMessageDialog(null, "Falt� digitar direccion", "ERROR....",JOptionPane.ERROR_MESSAGE);
		}
		jtaResultado.setText("");
		// IMPRESION DE VARIAS VARIABLES EN UNA LINEA
		jtaResultado.append(nombre+"     "+direccion+"   "+estadoCivil+"   "+ciudad+"   "+sexo+"\n");
		
		// IMPRESION DE VARIABLES EN LINEAS SEPARADAS
		jtaResultado.append(nombre+"\n");
		jtaResultado.append(direccion+"\n");
		jtaResultado.append(estadoCivil+"\n");
		jtaResultado.append(ciudad+"\n");
		jtaResultado.append(sexo+"\n");
		//JCheckBox cbMusica,cbDanza, cbFutbol, cbPasear,cbLectura
		jtaResultado.append("Mis Hobbyes son:"+"\n");
		//VALIDANDO CUALES CHECKBOX FUERON SELECCIONADOS
		if(cbMusica.isSelected()){
			sentinela=sentinela+1;
			jtaResultado.append("Musica"+"\n");
		}
		if(cbDanza.isSelected()){
			sentinela++;
			jtaResultado.append("Danza"+"\n");
		}
		if(cbFutbol.isSelected()){
			sentinela++;
			jtaResultado.append("Futbol"+"\n");
		}
		if(cbPasear.isSelected()){
			sentinela++;
			jtaResultado.append("Pasear"+"\n");
		}
		if(cbLectura.isSelected()){
			sentinela++;
			jtaResultado.append("Lectura"+"\n");
		}
		
		if(ciudad.equals("Seleccione una Ciudad")){
			 JOptionPane.showMessageDialog(null, "Faltó seleccionar una ciudad del listado", "ERROR....",JOptionPane.ERROR_MESSAGE);
		}
		
		if(estadoCivil.equals("Seleccione un Estado Civil")){
			 JOptionPane.showMessageDialog(null, "Faltó seleccionar un ESTADO CIVIL del listado", "ERROR....",JOptionPane.ERROR_MESSAGE);
		}
		
		if(sentinela==0){
			JOptionPane.showMessageDialog(null, "Faltó seleccionar un HOBBYE del listado", "ERROR....",JOptionPane.ERROR_MESSAGE);
		}
     }
	
    if(evento.equals(CANCELAR)){
    	jtaResultado.setText("");
    	txtNombre.setText("");
    	txtDireccion.setText("");
    	cbFutbol.setSelected(false);
    	cbLectura.setSelected(false);
    	cbPasear.setSelected(false);
    	cbDanza.setSelected(false);
    	cbMusica.setSelected(false);
    	rbMasculino.setSelected(false);
    	cboCiudad.setSelectedIndex(0);
    	cboEstadoCivil.setSelectedIndex(0);
	}
    
    if(evento.equals(CONSULTAR)){
    	int respuesta=JOptionPane.showConfirmDialog(null,"Usa mucho el JOptionPane?"); 
    		    if (JOptionPane.OK_OPTION == respuesta){
    		    JOptionPane.showMessageDialog(null, "Ha seleccionado Afirmativo");
    		    } 
    		    
    		    if (JOptionPane.NO_OPTION == respuesta){
    		    JOptionPane.showMessageDialog(null, "Ha seleccionado Negativo");
    		    }

    		    if (JOptionPane.CANCEL_OPTION == respuesta){
    		    JOptionPane.showMessageDialog(null, "Ha Cancelado");
    		    }
     }
    
     if(evento.equals(SALIR)){
    	JOptionPane.showMessageDialog(null,"Pulse una tecla para Abandonar el Programa");
		System.exit(0);
	 }
  }

  public static void main(String[] args){
	 InterfazGrafica formulario=new InterfazGrafica();
	 formulario.setVisible(true);
     }
}










